#ifndef PING6_H_
#define PING6_H_

#include "contiki.h"

PROCESS_NAME(ping6_process);

#endif /* PING6_H_ */
